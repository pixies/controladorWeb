<?php
// Heading
$_['heading_title']		= 'Yahoo';

// Text 
$_['text_payment']		= 'Feeds de produtos';
$_['text_success']		= 'Feed Yahoo atualizado com sucesso!';
$_['text_development']	= '<span style="color: red;">Em desenvolvimento</span>';
?>
