<?php
// Heading
$_['heading_title']		= 'Promoções';

// Text
$_['text_module']		= 'Módulos';
$_['text_success']		= 'Módulo Promoções atualizado com sucesso!';
$_['text_left']			= 'Esqueda';
$_['text_right']		= 'Direita';

// Entry
$_['entry_limit']		= 'Limite:';
$_['entry_position']	= 'Posição:';
$_['entry_status']		= 'Situação:';
$_['entry_sort_order']	= 'Ordem:';

// Error
$_['error_permission']	= 'Atenção: Você não possui permissão para modificar o módulo Promoções!';
?>