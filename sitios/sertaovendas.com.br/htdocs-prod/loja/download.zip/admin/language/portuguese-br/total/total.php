<?php
// Heading
$_['heading_title']    = 'Total';

// Text
$_['text_total']       = 'Total do pedido';
$_['text_success']     = 'Total atualizado com sucesso!';

// Entry
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o total!';
?>
