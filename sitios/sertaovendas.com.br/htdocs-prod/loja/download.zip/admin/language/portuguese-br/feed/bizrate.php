<?php
// Heading
$_['heading_title']		= 'BizRate';

// Text 
$_['text_payment']		= 'Pagamento';
$_['text_success']		= 'Feed BizRate atualizado com sucesso!';
$_['text_development']	= '<span style="color: red;">Em desenvolvimento</span>';
?>
