<?php
// Heading
$_['heading_title'] = 'Permissão negada!'; 

// Text
$_['text_permission'] = 'Você não possui permissão para acessar esta página. Por favor, entre em contato conosco.';
?>