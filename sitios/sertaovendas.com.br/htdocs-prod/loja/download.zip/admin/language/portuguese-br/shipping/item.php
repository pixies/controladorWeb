<?php 
// Heading
$_['heading_title']     = 'Por Item';

// Text
$_['text_shipping']    = 'Frete';
$_['text_success']     = 'Frete Por Item atualizado com sucesso!';

// Entry
$_['entry_cost']       = 'Custo:';
$_['entry_tax']        = 'Classe de imposto:';
$_['entry_geo_zone']   = 'Região geográfica:';
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordenação:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o frete Por Item!';
?>