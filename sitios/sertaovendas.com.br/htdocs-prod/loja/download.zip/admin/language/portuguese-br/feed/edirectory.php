<?php
// Heading
$_['heading_title']		= 'eDirectory';

// Text 
$_['text_payment']		= 'Pagamento';
$_['text_success']		= 'Feed eDirectory atualizado com sucesso!';
$_['text_development']	= '<span style="color: red;">Em desenvolvimento</span>';
?>
