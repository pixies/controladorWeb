<?php
// Text
$_['text_subject']	= '%s - Sua conta foi ativada!';
$_['text_welcome']	= 'Bem-vindo(a) e muito obrigado por se cadastrar em %s!';
$_['text_login']	= 'Sua conta já foi criada e você pode efetuar o acesso usando seu endereço de e-mail e senha. Para isso, visite nosso website ou clique na seguinte URL:';
$_['text_services']	= 'Ao efetuar o acesso você será capaz de acessar outros serviços, incluindo revisão de compras passadas, impressão de faturas e edição de informações de sua conta.';
$_['text_thanks']	= 'Obrigado,';
?>