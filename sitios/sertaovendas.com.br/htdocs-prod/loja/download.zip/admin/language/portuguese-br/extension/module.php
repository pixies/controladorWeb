<?php
// Heading
$_['heading_title']		= 'Módulos';

// Text
$_['text_install']		= 'Instalar';
$_['text_uninstall']	= 'Desinstalar';
$_['text_left']			= 'Esquerda';
$_['text_right']		= 'Direita';

// Column
$_['column_name']		= 'Nome do módulo';
$_['column_position']	= 'Posição';
$_['column_status']		= 'Situação';
$_['column_sort_order']	= 'Ordem';
$_['column_action']		= 'Ação';

// Error
$_['error_permission']  = 'Atenção: Você não tem permissão para modificar os Módulos!';
?>