<?php
// Heading
$_['heading_title']		= 'Google Base';

// Text
$_['text_feed']			= 'Feeds de produtos';
$_['text_success']		= 'Feed Google Base atualizado com sucesso!';

// Entry
$_['entry_status']		= 'Situação:';
$_['entry_data_feed']	= 'Url do feed:';

// Error
$_['error_permission']	= 'Atenção: Você não possui permissão para modificar o feed Google Base!';
?>
