<?php
// Heading
$_['heading_title']    = 'Taxa de Manuseio';

// Text
$_['text_total']       = 'Total do pedido';
$_['text_success']     = 'Taxa de manuseio atualizado com sucesso!';

// Entry
$_['entry_total']      = 'Total do pedido:';
$_['entry_fee']        = 'Taxa:';
$_['entry_tax']        = 'Classe de impostos:';
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar a taxa de manuseio!';
?>