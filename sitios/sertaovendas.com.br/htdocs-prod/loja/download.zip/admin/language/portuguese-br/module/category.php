<?php
// Heading
$_['heading_title']		= 'Categorias';

// Text
$_['text_module']		= 'Módulos';
$_['text_success']		= 'Módulo Categorias atualizado com sucesso!';
$_['text_left']			= 'Esquerda';
$_['text_right']		= 'Direita';

// Entry
$_['entry_position']	= 'Posição:';
$_['entry_status']		= 'Situação:';
$_['entry_sort_order']	= 'Ordem:';

// Error
$_['error_permission']	= 'Atenção: Você não possui permissão para modificar o módulo Categorias!';
?>