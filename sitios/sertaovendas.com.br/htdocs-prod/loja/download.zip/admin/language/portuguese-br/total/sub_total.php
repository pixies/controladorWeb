<?php
// Heading
$_['heading_title']    = 'Sub-total';

// Text
$_['text_total']       = 'Total do pedido';
$_['text_success']     = 'Sub-total atualizado com sucesso!';

// Entry
$_['entry_status']     = 'Situação:';
$_['entry_sort_order'] = 'Ordem:';

// Error
$_['error_permission'] = 'Atenção: Você não possui permissão para modificar o sub-total!';
?>
