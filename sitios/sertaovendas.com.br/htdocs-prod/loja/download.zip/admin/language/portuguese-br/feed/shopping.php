<?php
// Heading
$_['heading_title']		= 'Shopping.com';

// Text 
$_['text_payment']		= 'Feeds de produtos';
$_['text_success']		= 'Feed Shopping.com atualizado com sucesso!';
$_['text_development']	= '<span style="color: red;">Em desenvolvimento</span>';
?>
