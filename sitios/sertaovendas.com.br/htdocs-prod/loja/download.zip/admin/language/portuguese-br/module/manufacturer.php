<?php
// Heading
$_['heading_title']		= 'Fabricantes';

// Text
$_['text_module']		= 'Módulos';
$_['text_success']		= 'Módulo Fabricantes atualizado com sucesso!';
$_['text_left']			= 'Esquerda';
$_['text_right']		= 'Direita';

// Entry
$_['entry_position']	= 'Posição:';
$_['entry_status']		= 'Situação:';
$_['entry_sort_order']	= 'Ordem:';

// Error
$_['error_permission']	= 'Atenção: Você não possui permissão para alterar o módulo Fabricantes!';
?>