<?php
// Heading
$_['heading_title']  = 'Relatório de produtos visualizados';

// Text
$_['text_success']   = 'Relatório de produtos visualizados atualizado com sucesso!';

// Column
$_['column_name']    = 'Nome do produto';
$_['column_model']   = 'Modelo';
$_['column_viewed']  = 'Visualizado';
$_['column_percent'] = 'Porcentagem';
?>
