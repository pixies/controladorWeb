<?php
// Heading
$_['heading_title']		= 'BidHopper';

// Text 
$_['text_payment']		= 'Pagamento';
$_['text_success']		= 'Feed BidHopper atualizado com sucesso!';
$_['text_development']	= '<span style="color: red;">Em desenvolvimento</span>';
?>
