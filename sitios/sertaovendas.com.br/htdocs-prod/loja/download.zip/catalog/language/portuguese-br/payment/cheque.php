<?php
// Text
$_['text_title']   = 'Cheque / Ordem de Pagamento';
$_['text_payable'] = 'Nominal a: ';
$_['text_address'] = 'Enviar para: ';
$_['text_payment'] = 'Enviaremos seu pedido assim que recebermos a confirma��o do pagamento.';
?>