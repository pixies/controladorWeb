<?php
// Heading
$_['heading_title']     = 'Obrigado por comprar na loja %s!';

// Text
$_['text_title']        = 'Cartão de Crédito/Débito (PayPoint)';
$_['text_response']     = 'Resposta da PayPoint:';
$_['text_success']      = '... seu pagamento foi recebido com sucesso.';
$_['text_success_wait'] = 'Por favor, aguarde enquanto finalizamos o processamento de seu pedido.<br />Se você não for automaticamente redirecionado em 10 segundos, por favor, clique <a href="%s">aqui</a>.';
$_['text_failure']      = '... seu pagamento foi cancelado!';
$_['text_failure_wait'] = 'Por favor, aguarde...<br />Se você não for automaticamente redirecionado em 10 segundos, por favor, clique <a href="%s">aqui</a>.';
?>