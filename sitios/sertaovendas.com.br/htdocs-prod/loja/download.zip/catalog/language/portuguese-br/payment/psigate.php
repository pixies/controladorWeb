<?php
// Text
$_['text_title'] = 'Cartão de Crédito/Débito (PSIGate)';
?>