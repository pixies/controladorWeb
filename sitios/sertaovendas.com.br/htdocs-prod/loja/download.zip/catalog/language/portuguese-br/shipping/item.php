<?php
// Text
$_['text_title']       = 'Por Item';
$_['text_description'] = 'Taxa de Frete por Item';
?>
