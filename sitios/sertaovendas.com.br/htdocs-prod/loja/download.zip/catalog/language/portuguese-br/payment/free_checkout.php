<?php
// Text
$_['text_title'] = 'Pagamento Grátis';
?>