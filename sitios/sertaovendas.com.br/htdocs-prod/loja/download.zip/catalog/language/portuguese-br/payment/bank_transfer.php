<?php
// Text
$_['text_title']       = 'Transferência Bancária';
$_['text_instruction'] = 'Por favor, realize o depósito ou transferência da quantia total para a seguinte conta bancária:';
$_['text_payment']     = 'Enviaremos seu pedido assim que recebermos a confirmação do pagamento.';
?>
