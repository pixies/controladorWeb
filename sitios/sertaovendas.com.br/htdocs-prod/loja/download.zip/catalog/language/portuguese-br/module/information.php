<?php
// Heading 
$_['heading_title'] = 'Informações';

// Text
$_['text_contact']  = 'Contate-nos';
$_['text_sitemap']  = 'Mapa do Site';
?>