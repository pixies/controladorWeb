<?php
// Heading 
$_['heading_title']  = 'Promoções';

// Text
$_['text_stars']     = '%s 5 Estrelas!';
$_['text_products']  = '';
?>