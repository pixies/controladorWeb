<?php
// Heading 
$_['heading_title']      = 'Minha Conta';

// Text
$_['text_account']       = 'Conta';
$_['text_my_account']    = 'Meus dados';
$_['text_my_orders']     = 'Meus pedidos';
$_['text_my_newsletter'] = 'Meu informativo';
$_['text_information']   = 'Alterar meus dados';
$_['text_password']      = 'Alterar minha senha';
$_['text_address']       = 'Alterar meus endereços';
$_['text_history']       = 'Histórico de pedidos';
$_['text_download']      = 'Downloads disponíveis';
$_['text_newsletter']    = 'Inscrição no informativo';
?>