<?php
// Text
$_['text_powered_by'] = 'Por <a href="http://www.opencart.com/">Open Cart</a><br /> %s &copy; %s';
?>
