<?php
// Heading 
$_['heading_title']    = 'Minha Inscrição no Informativo';

// Text
$_['text_account']     = 'Conta';
$_['text_newsletter']  = 'Inscrição no Informativo';
$_['text_success']     = 'Inscrição no informativo atualizada com sucesso!';

// Entry
$_['entry_newsletter'] = 'Fazer minha Inscrição:';
?>