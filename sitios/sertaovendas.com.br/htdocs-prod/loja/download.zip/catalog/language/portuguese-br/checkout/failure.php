<?php
// Heading 
$_['heading_title'] = 'Problema com o Pedido';

// Text
$_['text_basket']   = 'Carrinho';
$_['text_shipping'] = 'Entrega';
$_['text_payment']  = 'Pagamento';
$_['text_failure']  = 'Falha';
$_['text_message']  = '<p>Houve um problema ao tentar processar o seu pedido!</p><p>Se o problema persistir, por favor, tente selecionar um método de pagamento diferente. Caso deseje, entre em contato conosco <a href="%s">clicando aqui</a></p>.';
?>
