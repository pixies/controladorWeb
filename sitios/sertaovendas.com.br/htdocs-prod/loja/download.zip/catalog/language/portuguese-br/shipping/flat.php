<?php
// Text
$_['text_title']       = 'Taxa Única';
$_['text_description'] = 'Frete de Taxa Única';
?>
