<?php
// Mail
$_['text_subject']      = '%s - Informação Sobre Pedido %s';
$_['text_order']        = 'ID do pedido:';
$_['text_date_added']   = 'Data do pedido:';
$_['text_order_status'] = 'Seu pedido foi atualizado para a seguinte situação:';
$_['text_comment']      = 'Os comentários para o seu pedido são:';
$_['text_invoice']      = 'Para ver seu pedido, por favor, clique no link abaixo:';
$_['text_footer']       = 'Por favor, responda este e-mail se tiver alguma dúvida.';
?>