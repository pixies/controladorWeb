<?php
// Heading
$_['heading_title'] = 'A página solicitada não foi encontrada!';

// Text
$_['text_error']    = 'A página solicitada não foi encontrada.';
?>
