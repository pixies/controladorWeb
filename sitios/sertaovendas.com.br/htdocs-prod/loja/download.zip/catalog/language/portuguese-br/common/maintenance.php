<?php
// Heading
$_['heading_title']     = 'Manutenção';

// Text
$_['text_maintenance']  = 'Manutenção';
$_['text_message']      = '<h1 style="text-align:center;">Desculpe-nos, estamos fechados temporariamente para manutenção. <br/>Estaremos de volta tão logo possível.<br />Por favor, tente novamente em alguns minutos.</h1>';
?>