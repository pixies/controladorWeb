<?php
// Heading 
$_['heading_title']  = 'Novos';

// Text
$_['text_stars']     = '%s 5 Estrelas!';
$_['text_products']  = '';
?>