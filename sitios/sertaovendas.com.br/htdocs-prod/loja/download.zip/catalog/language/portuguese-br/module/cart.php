<?php
// Heading
$_['heading_title'] = 'Carrinho';

// Text 
$_['text_subtotal'] = 'Sub-total:';
$_['text_empty']    = 'Carrinho Vazio';
$_['text_confirm']  = 'Confirmar?';
$_['text_remove']   = 'Remover';
$_['text_view']     = 'Ver Carrinho';
$_['text_checkout'] = 'Finalizar';
?>
