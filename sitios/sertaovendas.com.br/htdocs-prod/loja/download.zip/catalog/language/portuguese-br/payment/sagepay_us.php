<?php
// Text
$_['text_title']           = 'Cartão de Crédito/Débito (SagePay)';
$_['text_credit_card']     = 'Detalhes do cartão';
$_['text_wait']            = 'Por favor, aguarde.';

// Entry
$_['entry_cc_owner']       = 'Proprietário:';
$_['entry_cc_number']      = 'Número do cartão:';
$_['entry_cc_expire_date'] = 'Válido até:';
$_['entry_cc_cvv2']        = 'Código de segurança (CVV2):';
?>
