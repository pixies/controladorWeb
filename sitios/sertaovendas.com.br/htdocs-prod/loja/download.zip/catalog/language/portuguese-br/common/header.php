<?php
// Text
$_['text_home']     = 'Principal';
$_['text_special']  = 'Promoções';
$_['text_contact']  = 'Contate-nos';
$_['text_sitemap']  = 'Mapa do Site';
$_['text_bookmark'] = 'Favoritos';
$_['text_account']  = 'Conta';
$_['text_login']    = 'Acessar';
$_['text_logout']   = 'Sair';
$_['text_cart']     = 'Carrinho';
$_['text_checkout'] = 'Finalizar';

$_['text_keyword']  = 'palavra-chave';
$_['text_advanced'] = 'Pesquisa avançada';
$_['text_category'] = 'Todas as categorias';

// Entry
$_['entry_search']   = 'Pesquisa por:';
?>
