<?php
// Text
$_['text_title']    = 'Frete por Peso';
$_['text_weight']   = 'Peso:';
$_['text_allzones'] = 'Todas as Regi�es Geogr�ficas';
?>
