<?php
// Heading 
$_['heading_title'] = 'Bem-vindo(a) a loja online %s!';

// Text
$_['text_latest']   = 'Novos Produtos';
?>
