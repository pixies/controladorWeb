<?php
// Heading
$_['heading_title']    = 'Mapa do Site';
 
// Text
$_['text_special']     = 'Promoções';
$_['text_account']     = 'Conta';
$_['text_edit']        = 'Meus dados';
$_['text_password']    = 'Minha senha';
$_['text_address']     = 'Meus endereços';
$_['text_history']     = 'Histórico de pedidos';
$_['text_download']    = 'Downloads disponíveis';
$_['text_cart']        = 'Carrinho de compras';
$_['text_checkout']    = 'Finalizar compra';
$_['text_search']      = 'Pesquisa avançada';
$_['text_information'] = 'Informações';
$_['text_contact']     = 'Contate-nos';
?>
