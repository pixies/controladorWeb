<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Peso:'; 
$_['text_insurance']   = 'Segurado até o valor de:';   
$_['text_time']        = 'Tempo estimado: até 48 horas'; 
?>
