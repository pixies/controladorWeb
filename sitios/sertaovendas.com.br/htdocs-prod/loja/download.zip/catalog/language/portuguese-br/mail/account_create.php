<?php
// Text
$_['text_subject']  = '%s - Obrigado por cadastrar-se conosco!';
$_['text_welcome']  = 'Seja bem-vindo(a) a loja %s e muito obrigado por cadastrar-se conosco!';
$_['text_login']    = 'Sua conta já foi criada e você pode efetuar seu acesso usando seu endereço de e-mail e senha visitando nossa loja através do link:';
$_['text_approval'] = 'Sua conta precisa ser aprovada antes que você possa realizar o acesso. Após a aprovação você poderá efetuar o acesso usando seu endereço de e-mail e senha visitando nossa loja através  do link:';
$_['text_services'] = 'Ao efetuar o acesso, você será capaz de acessar outros serviços, incluindo o acompanhamento de compras anteriores, a impressão de faturas e alteração de informações de sua conta.';
$_['text_thanks']   = 'Obrigado,';
?>