<?php
// Heading 
$_['heading_title']  = 'Atendimento via Chat';
?>
