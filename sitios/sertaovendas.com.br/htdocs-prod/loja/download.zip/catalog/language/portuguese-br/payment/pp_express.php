<?php
// Text
$_['text_title'] = 'PayPal Express (incluindo Cartões de Crédito/Débito)';
?>