<?php
// Text
$_['text_title']       = 'Frete Grátis';
$_['text_description'] = 'Frete Grátis';
?>
