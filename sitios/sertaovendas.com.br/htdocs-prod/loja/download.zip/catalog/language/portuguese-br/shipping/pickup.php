<?php
// Text
$_['text_title']       = 'Retirar na Loja';
$_['text_description'] = 'Retirar Produto Diretamente na Loja';
?>