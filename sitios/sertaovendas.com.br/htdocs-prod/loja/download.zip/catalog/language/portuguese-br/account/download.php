<?php
// Heading 
$_['heading_title']   = 'Meus Downloads Disponíveis';

// Text
$_['text_account']    = 'Conta';
$_['text_downloads']  = 'Downloads Disponíveis';
$_['text_order']      = 'Pedido:';
$_['text_date_added'] = 'Adicionado em:';
$_['text_name']       = 'Nome:';
$_['text_remaining']  = 'Restante:';
$_['text_size']       = 'Tamanho:';
$_['text_download']   = 'Download';
$_['text_error']      = 'Nenhum pedido de produto para download foi realizado até o momento.';
?>