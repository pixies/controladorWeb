<?php
// Heading 
$_['heading_title']   = 'Meu Histórico de Pedidos';

// Text
$_['text_account']    = 'Conta';
$_['text_history']    = 'Histórico de Pedidos';
$_['text_order']      = 'Pedido:';
$_['text_status']     = 'Situação:';
$_['text_date_added'] = 'Data:';
$_['text_customer']   = 'Cliente:';
$_['text_products']   = 'Produtos:';
$_['text_total']      = 'Total:';
$_['text_error']      = 'Nenhum pedido realizado até o momento.';
?>